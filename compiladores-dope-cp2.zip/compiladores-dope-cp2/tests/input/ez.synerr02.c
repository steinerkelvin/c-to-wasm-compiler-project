int print_int(int);

int main() {
    int x = 0;
    if (x == 2) {
        print_int(x);
    // Missing end of if compound statement block
    return 0;
}
