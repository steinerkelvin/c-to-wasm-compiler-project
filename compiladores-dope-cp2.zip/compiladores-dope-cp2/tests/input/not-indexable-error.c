int main(){
    float r;
    r[2];
}
