int main() {
    int x;
    x = 4 \ 2;  // Should be /
}
