int main() {
  int x == 2; // Equality is not assignment
}
