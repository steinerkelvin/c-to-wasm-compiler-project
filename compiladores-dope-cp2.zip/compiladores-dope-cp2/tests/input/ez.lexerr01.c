int main() {
  int $0 = 11;
}
