
int main() {
    float vec[8];
    char c;
    int i;
    float r;
    vec[c]; // should work
    vec[i]; // should work
    vec[r]; // ERROR
}
