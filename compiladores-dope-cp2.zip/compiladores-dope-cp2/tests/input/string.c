
int main() {
    "Hello, world!";
    const char* txt = "Hello, world!";
    txt;
    return 0;
}
