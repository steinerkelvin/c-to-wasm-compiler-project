/* The mandatory test program. Prints "Hello, world!" to the screen */

int print(const char *str);

int main() {
    print("Hello, world!\n");
    return 0;
}
