int main() {
    int x = 5;
    2 = x;
}
