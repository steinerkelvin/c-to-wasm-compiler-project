
int main() {
    int vec[2];
    vec();
}
