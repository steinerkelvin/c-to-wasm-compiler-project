void func();

int main() {
    int *p;
    float r;
    // !p; // TODO should work
    ~r;
    +p;
    -p;
    + func();
    - func();
    ! func();
}
