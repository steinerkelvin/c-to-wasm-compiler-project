int main() {
  int x = 42
}
