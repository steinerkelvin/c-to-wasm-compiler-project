int grobaru = 0;

int *test(int a, int b) {
    return 0;
}

int main()
{
    int (*f)(int a, int b);
    f;

    int x = 1.5;

    int vec[4][8];
    vec[3][7];

    int **p;
    p;

    if (x) {
        0 * 1 + 0 * (-2.4);
    }

    while(x/2) {
        1 + 3;
    }
}
