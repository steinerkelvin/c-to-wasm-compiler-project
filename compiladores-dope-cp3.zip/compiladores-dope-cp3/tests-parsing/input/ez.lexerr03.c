int main() {
    int x = 4 # 2;  // Unknown operator '#'
}
