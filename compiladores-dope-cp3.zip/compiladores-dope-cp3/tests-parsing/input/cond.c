
int main() {
    int i;
    float r;

    if (i) {
        i;
    }
    while (i) {
        i;
    }
    do {
        i;
    } while (i);
    // if (r) { // ERROR
    //     r;
    // }
}
