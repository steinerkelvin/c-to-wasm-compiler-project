int main() {
    int* p;
    p = &2;
}
