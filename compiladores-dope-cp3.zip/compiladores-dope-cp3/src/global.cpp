#include "global.hpp"
ast::Expr* last_expr;
ast::Program* root;
types::Type* res_type;
