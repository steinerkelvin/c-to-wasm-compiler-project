- organize codegen tests
- rand on JS runtime
- handle specific instructions for some arithmetic on floats
- int / float type coersion

- code generation for global variable initialization

- type check return value
- check return in all control paths
- allow defining already declared function

- detect expressions with no side effects?
